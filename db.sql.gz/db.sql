-- MySQL dump 10.13  Distrib 8.0.40, for Linux (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Floor`
--

DROP TABLE IF EXISTS `Floor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Floor` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ParkingGarage_Id` int NOT NULL,
  `Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `ParkingGarage_Id` (`ParkingGarage_Id`),
  CONSTRAINT `fk_floor_to_parkingGarage` FOREIGN KEY (`ParkingGarage_Id`) REFERENCES `ParkingGarage` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Floor`
--

LOCK TABLES `Floor` WRITE;
/*!40000 ALTER TABLE `Floor` DISABLE KEYS */;
INSERT INTO `Floor` VALUES (1,1,'1. UG'),(2,1,'2. UG'),(3,2,'1. UG'),(4,2,'2. UG'),(5,2,'3. UG'),(6,3,'1. UG');
/*!40000 ALTER TABLE `Floor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ParkingGarage`
--

DROP TABLE IF EXISTS `ParkingGarage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ParkingGarage` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ParkingGarage`
--

LOCK TABLES `ParkingGarage` WRITE;
/*!40000 ALTER TABLE `ParkingGarage` DISABLE KEYS */;
INSERT INTO `ParkingGarage` VALUES (1,'Bern Westside'),(2,'Bern City'),(3,'Baseltor');
/*!40000 ALTER TABLE `ParkingGarage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ParkingSpace`
--

DROP TABLE IF EXISTS `ParkingSpace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ParkingSpace` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Floor_Id` int NOT NULL,
  `ParkingSpaceState_Id` int NOT NULL,
  `Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `Floor_Id` (`Floor_Id`),
  KEY `ParkingSpaceState_Id` (`ParkingSpaceState_Id`),
  CONSTRAINT `fk_parkingSpace_to_floor` FOREIGN KEY (`Floor_Id`) REFERENCES `Floor` (`Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_parkingSpace_to_parkingSpaceState` FOREIGN KEY (`ParkingSpaceState_Id`) REFERENCES `ParkingSpaceState` (`Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ParkingSpace`
--

LOCK TABLES `ParkingSpace` WRITE;
/*!40000 ALTER TABLE `ParkingSpace` DISABLE KEYS */;
INSERT INTO `ParkingSpace` VALUES (9,6,1,'1'),(10,5,1,'1'),(11,4,1,'1'),(12,3,1,'1'),(13,2,2,'1'),(14,1,2,'1'),(15,6,1,'2'),(16,5,1,'2'),(17,4,1,'2'),(18,3,1,'2'),(19,2,2,'2'),(20,1,2,'2'),(21,6,1,'3'),(22,5,1,'3'),(23,4,1,'3'),(24,3,1,'3'),(25,2,1,'3'),(26,1,1,'3'),(27,6,1,'4'),(28,5,1,'4'),(29,4,1,'4'),(30,3,1,'4'),(31,2,1,'4'),(32,1,1,'4'),(33,6,1,'5'),(34,5,1,'5'),(35,4,1,'5'),(36,3,1,'5'),(37,2,1,'5'),(38,1,1,'5'),(39,6,1,'6'),(40,5,1,'6'),(41,4,1,'6'),(42,3,1,'6'),(43,2,1,'6'),(44,1,1,'6'),(45,6,1,'7'),(46,5,1,'7'),(47,4,1,'7'),(48,3,1,'7'),(49,2,1,'7'),(50,1,1,'7'),(51,6,1,'8'),(52,5,1,'8'),(53,4,1,'8'),(54,3,1,'8'),(55,2,1,'8'),(56,1,1,'8'),(57,6,1,'9'),(58,5,1,'9'),(59,4,1,'9'),(60,3,1,'9'),(61,2,1,'9'),(62,1,1,'9'),(63,6,1,'10'),(64,5,1,'10'),(65,4,1,'10'),(66,3,1,'10'),(67,2,1,'10'),(68,1,1,'10'),(69,6,1,'11'),(70,5,1,'11'),(71,4,1,'11'),(72,3,1,'11'),(73,2,1,'11'),(74,1,1,'11'),(75,6,1,'12'),(76,5,1,'12'),(77,4,1,'12'),(78,3,1,'12'),(79,2,1,'12'),(80,1,1,'12'),(81,6,1,'13'),(82,5,1,'13'),(83,4,1,'13'),(84,3,1,'13'),(85,2,1,'13'),(86,1,1,'13'),(87,6,1,'14'),(88,5,1,'14'),(89,4,1,'14'),(90,3,1,'14'),(91,2,1,'14'),(92,1,1,'14'),(93,6,1,'15'),(94,5,1,'15'),(95,4,1,'15'),(96,3,1,'15'),(97,2,1,'15'),(98,1,1,'15');
/*!40000 ALTER TABLE `ParkingSpace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ParkingSpaceState`
--

DROP TABLE IF EXISTS `ParkingSpaceState`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ParkingSpaceState` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ParkingSpaceState`
--

LOCK TABLES `ParkingSpaceState` WRITE;
/*!40000 ALTER TABLE `ParkingSpaceState` DISABLE KEYS */;
INSERT INTO `ParkingSpaceState` VALUES (1,'Available'),(2,'Occupied'),(3,'Rented');
/*!40000 ALTER TABLE `ParkingSpaceState` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pricing`
--

DROP TABLE IF EXISTS `Pricing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Pricing` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ParkingGarage_Id` int NOT NULL,
  `PricingType_Id` int NOT NULL,
  `Price` float NOT NULL,
  `ApplicableFrom` time NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_pricing_pricingType` (`PricingType_Id`),
  KEY `fk_pricing_parkingGarage` (`ParkingGarage_Id`),
  CONSTRAINT `fk_pricing_parkingGarage` FOREIGN KEY (`ParkingGarage_Id`) REFERENCES `ParkingGarage` (`Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_pricing_pricingType` FOREIGN KEY (`PricingType_Id`) REFERENCES `PricingType` (`Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pricing`
--

LOCK TABLES `Pricing` WRITE;
/*!40000 ALTER TABLE `Pricing` DISABLE KEYS */;
INSERT INTO `Pricing` VALUES (1,1,1,2.5,'00:00:00'),(2,1,1,2.8,'06:00:00'),(3,1,1,3.6,'09:00:00'),(4,1,1,2.8,'18:00:00'),(5,1,1,2.4,'21:00:00'),(6,1,2,2.4,'00:00:00'),(7,1,2,3.2,'09:00:00'),(8,1,2,2.4,'18:00:00'),(9,2,1,2.5,'00:00:00'),(10,2,1,2.8,'06:00:00'),(11,2,1,3.6,'09:00:00'),(12,2,1,2.8,'18:00:00'),(13,2,1,2.4,'21:00:00'),(14,2,2,2.4,'00:00:00'),(15,2,2,3.2,'09:00:00'),(16,2,2,2.4,'18:00:00'),(17,3,1,2.5,'00:00:00'),(18,3,1,2.8,'06:00:00'),(19,3,1,3.6,'09:00:00'),(20,3,1,2.8,'18:00:00'),(21,3,1,2.4,'21:00:00'),(22,3,2,2.4,'00:00:00'),(23,3,2,3.2,'09:00:00'),(24,3,2,2.4,'18:00:00');
/*!40000 ALTER TABLE `Pricing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PricingDayMapping`
--

DROP TABLE IF EXISTS `PricingDayMapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PricingDayMapping` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PricingType_Id` int NOT NULL,
  `DayIndex` int NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_pricingDayMapping_PricingType` (`PricingType_Id`),
  CONSTRAINT `fk_pricingDayMapping_PricingType` FOREIGN KEY (`PricingType_Id`) REFERENCES `PricingType` (`Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PricingDayMapping`
--

LOCK TABLES `PricingDayMapping` WRITE;
/*!40000 ALTER TABLE `PricingDayMapping` DISABLE KEYS */;
INSERT INTO `PricingDayMapping` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,2,6),(7,2,7);
/*!40000 ALTER TABLE `PricingDayMapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PricingException`
--

DROP TABLE IF EXISTS `PricingException`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PricingException` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PricingType_Id` int NOT NULL,
  `Date` date NOT NULL,
  `Name` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_pricingExceptions_pricingType` (`PricingType_Id`),
  CONSTRAINT `fk_pricingExceptions_pricingType` FOREIGN KEY (`PricingType_Id`) REFERENCES `PricingType` (`Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PricingException`
--

LOCK TABLES `PricingException` WRITE;
/*!40000 ALTER TABLE `PricingException` DISABLE KEYS */;
INSERT INTO `PricingException` VALUES (1,2,'2026-01-01','Neujahr'),(2,2,'2026-01-02','Berchtoldstag'),(3,2,'2026-04-03','Karfreitag'),(4,2,'2026-04-06','Ostermontag'),(5,2,'2026-05-14','Auffahrt'),(6,2,'2026-05-25','Pfingstmontag'),(7,2,'2026-08-01','Bundesfeier (Nationalfeiertag)'),(8,2,'2026-09-20','Eidg. Dank-, Buss- und Bettag'),(9,2,'2026-12-25','Weihnachten'),(10,2,'2026-12-26','Stephanstag');
/*!40000 ALTER TABLE `PricingException` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PricingType`
--

DROP TABLE IF EXISTS `PricingType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PricingType` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PricingType`
--

LOCK TABLES `PricingType` WRITE;
/*!40000 ALTER TABLE `PricingType` DISABLE KEYS */;
INSERT INTO `PricingType` VALUES (1,'Wochentage'),(2,'Wochenende und Feiertage');
/*!40000 ALTER TABLE `PricingType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Ticket`
--

DROP TABLE IF EXISTS `Ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Ticket` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Floor_Id` int NOT NULL,
  `ParkingSpace_Id` int NOT NULL,
  `Arrival` datetime NOT NULL,
  `Departure` datetime DEFAULT NULL,
  `Identifier` varchar(36) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_ticket_to_floor` (`Floor_Id`),
  KEY `fk_ticket_to_parkingSpace` (`ParkingSpace_Id`),
  CONSTRAINT `fk_ticket_to_floor` FOREIGN KEY (`Floor_Id`) REFERENCES `Floor` (`Id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `fk_ticket_to_parkingSpace` FOREIGN KEY (`ParkingSpace_Id`) REFERENCES `ParkingSpace` (`Id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Ticket`
--

LOCK TABLES `Ticket` WRITE;
/*!40000 ALTER TABLE `Ticket` DISABLE KEYS */;
INSERT INTO `Ticket` VALUES (69,2,13,'2026-05-10 16:44:23','2026-05-10 16:48:00','63dd6496-b149-40de-9fa5-a8d887245a57'),(70,1,14,'2026-05-10 16:44:52',NULL,'32335c24-1ee4-4f18-b329-f8968defffeb'),(71,2,19,'2026-05-10 16:47:12',NULL,'00b48c1b-ac46-41ec-ad56-d59c10c3817a'),(72,1,20,'2026-05-10 16:47:30',NULL,'9896dd31-fddb-4e76-b26b-8a390cc074d4'),(73,2,13,'2026-05-10 16:48:03',NULL,'768c5ba8-c347-4362-9aec-97a36a1c00e0'),(74,6,9,'2026-05-10 17:01:39','2026-05-10 17:01:42','c2929164-3d25-4aff-aa56-81a57ab5e559');
/*!40000 ALTER TABLE `Ticket` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-10 18:32:28
